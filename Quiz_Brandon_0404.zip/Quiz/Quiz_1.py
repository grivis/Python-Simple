'''
Simple reading from a text file
'''
print('\nOpen and close a file')
text_file = open('read.txt', 'r', encoding='utf-8')
'''print(text_file)'''
text_file.close()

'''Open again and read symbol by symbol'''
''' \n - newline symbol '''
print('\nRead symbol by symbol')
text_file = open('read.txt', 'r', encoding='utf-8')
L1 = text_file.read(1)
L5 = text_file.read(5)
L11 = text_file.read(11)
print(L1+L5+L11)
text_file.close()

''' Open again and read the whole file'''
print('\nThe file as a whole')
text_file = open('read.txt', 'r', encoding='utf-8')
whole_thing = text_file.read()
print(whole_thing)
text_file.close()

''' Read line by line '''
print('\nThe file line by line')
text_file = open('read.txt', 'r', encoding='utf-8')
LineOne = text_file.readline()
LineTwo = text_file.readline()
LineThree = text_file.readline()
print(LineOne, end='')
print(LineTwo, end='')
print(LineThree, end='')
text_file.close()

''' Read a few symbols from a line '''
print('\nA few symbols from a line')
text_file = open('read.txt', 'r', encoding='utf-8')
LineOne = text_file.readline()
LineTwo = text_file.readline(5)
LineThree = text_file.readline(11)
print(LineOne, end='')
print(LineTwo, end='')
print(LineThree, end='')
text_file.close()







