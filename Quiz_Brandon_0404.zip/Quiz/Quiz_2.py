'''
Quiz game.
It uses files to store questions and answers
File name trivia.txt

How does the file look like?

7 lines

Question's topic e.g. Cities of Europe
Question itself e.g. What is the capital city of Germany?
Option 1 Frankfurt
Option 2 Hamburg
Option 3 Berlin
Option 4 Potsdam
3
'''
import sys

print('\nWelcome to our Quiz game')
print("It's a multiple choise game\n")
try:
      thetext = open('trivia1.txt', 'r', encoding='utf-8')
except:
      print('\nSorry, can not open the question file!')
      print('The program will be closed!')
      sys.exit()
topic = thetext.readline()
print('\nThe topic now is', topic)
question = thetext.readline()
print('The question is', question)
for i in range(1, 5):# 1 2 3 4
      option = thetext.readline()
      print('(', i, ')', option, end='')
usersays = None
while usersays not in ['1', '2', '3', '4']:
    usersays = input('\nWhat is your answer? (1-4)')
usersays = int(usersays)
correct = int(thetext.readline())
if correct == usersays:
    print('\nCongratulations! You know so much about', topic)
else:
    print('\nSorry! You have to learn more about', topic)
    
