'''
New version of the Quiz game
Now we are going to use all question files available
To do this, we need a loop
'''

import sys
import glob

def playround(filename):
    try:
          thetext = open(filename, 'r', encoding='utf-8')
    except:
          print('\nSorry, can not open the question file!')
          print('The program will be closed!')
          sys.exit()
    topic = thetext.readline()
    print('\nThe topic now is', topic)
    question = thetext.readline()
    print('The question is', question)
    for i in range(1, 5):# 1 2 3 4
          option = thetext.readline()
          print('(', i, ')', option, end='')
    usersays = None
    while usersays not in ['1', '2', '3', '4']:
        usersays = input('\nWhat is your answer? (1-4)')
    usersays = int(usersays)
    correct = int(thetext.readline())
    if correct == usersays:
        print('\nCongratulations! You know so much about', topic)
    else:
        print('\nSorry! You have to learn more about', topic)


''' The main part of the program starts here '''
print('\nWelcome to our Quiz game')
print("It's a multiple choise game\n")
allfiles = glob.glob('trivia*.txt')
questions_left = len(allfiles)
for filename in glob.glob('trivia*.txt'):
    playround(filename)
    usersays = None
    while usersays not in ['Y', 'N', 'yes', 'no', 'Yes', 'No']:
        usersays = input('\nDo you want to continue? (Yes/No)')
    if usersays in ['N', 'no', 'No']:
        break
print('\nThank you for playing our Quiz!')

#Try to finish the program:
# Count how many questions are left after each play
#If there are no questions (trivia files) left,
#do not ask the user whether he wants to continue
#Just finish the game
        
        

    
